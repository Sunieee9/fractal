
from turtle import *
import random

speed(1000)

def grow(length, decrease, angle, noise=0):
    if length > 10:
        forward(length)

        new_length =  length * decrease
        if noise > 0:
            new_length *= random.uniform(0.9, 1.1)

        angle_l = angle + random.gauss(0, noise)
        angle_r = angle + random.gauss(0, noise)

        left(angle_l)
        grow(new_length, decrease, angle, noise)
        right(angle_l)

        right(angle_r)
        grow(new_length, decrease, angle, noise)
        left(angle_r)

        backward(length)

penup()
goto(0, -400)
pendown()
left(90)
grow(200, 0.7, 40, 5)

tracer(True)
exitonclick()